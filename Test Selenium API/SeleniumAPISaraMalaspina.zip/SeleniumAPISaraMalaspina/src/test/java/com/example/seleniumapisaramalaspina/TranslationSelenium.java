package com.example.seleniumapisaramalaspina;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class TranslationSelenium {

    public String italianTranslation(String s){
        System.setProperty("webdriver.chrome.driver", "/Users/saramalaspina/Desktop/SeleniumAPISaraMalaspina/src/test/java/Driver/chromedriver");

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        WebDriver driver = new ChromeDriver(options);

        driver.get("https://www.google.com/search?q=google+traduttore&rlz=1C5CHFA_enIT974IT974&oq=goo&aqs=chrome.0.69i59j46i131i199i433i465i512j0i131i433i512j69i64j69i65j69i60l3.912j0j7&sourceid=chrome&ie=UTF-8");
        driver.manage().window().fullscreen();

        driver.findElement(By.xpath("//*[@id=\"W0wltc\"]")).click();

        try {
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"tw-source-text-ta\"]")).click();

        try {
            Thread.sleep(1000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        WebElement stringInput = driver.findElement(By.xpath("//*[@id=\"tw-source-text-ta\"]"));
        stringInput.sendKeys(s);

        try {
            Thread.sleep(3000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        String translation = driver.findElement(By.xpath("//*[@id=\"tw-target-text\"]/span")).getAttribute("textContent");
        driver.close();


        return translation;

    }

}
