package com.example.seleniumapisaramalaspina;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class TranslationSeleniumTest {

    @Test
    public void testEnToItalian(){
        TranslationSelenium translationSelenium = new TranslationSelenium();
        String translation = translationSelenium.italianTranslation("moon");
        assertEquals("luna",translation);
    }
}
