package com.ispw.perelliseleniumapi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

// page_url = https://www.jetbrains.com/
public class ConvertKmSelenium {

    //PERELLI

    public int KmToMeters(String km){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\silvi\\Desktop\\PerelliSeleniumAPI\\src\\test\\java\\driver\\chromedriver.exe");

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        ChromeDriver driver = new ChromeDriver(options);

        driver.get("https://convertlive.com/it/u/convertire/chilometri/a/metri");

        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"convert-value\"]")).click();


        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement input = driver.findElement(By.xpath("//*[@id=\"convert-value\"]"));
        input.sendKeys(km);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.xpath("//*[@id=\"convert-submit\"]")).click();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String meters = driver.findElement(By.xpath("//*[@id=\"converter\"]/div[4]/p/span[4]")).getAttribute("textContent");
        driver.close();
        return Integer.parseInt(meters);

    }
  }
