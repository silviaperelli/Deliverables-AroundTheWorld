package com.ispw.perelliseleniumapi;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConvertKmSeleniumTest {

    //PERELLI

    @Test
    public void testKmToMeters(){

        ConvertKmSelenium convertKmSelenium = new ConvertKmSelenium();
        int meters = convertKmSelenium.KmToMeters("8");
        assertEquals(8000,meters);
    }
}
